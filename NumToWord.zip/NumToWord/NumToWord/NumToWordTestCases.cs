﻿using NumToWord.NumbersToWords;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace NumToWord
{
    [TestFixture]
    public class NumToWordTestCases
    {
        NumToWordService objnumbertowords = new NumToWordService();

        #region Number Validation Test Cases
        [TestCase]
        public void ValidateNumber()
        {
            Assert.AreEqual(true, objnumbertowords.ValidateNumber("9"));
        }
        [TestCase]
        public void ValidateNumberString()
        {
            Assert.AreEqual(true, objnumbertowords.ValidateNumber("a"));
        }
        [TestCase]
        public void ValidateNumberDot()
        {
            Assert.AreEqual(true, objnumbertowords.ValidateNumber("."));
        }
        [TestCase]
        public void ValidateNumberEmpty()
        {
            Assert.AreEqual(true, objnumbertowords.ValidateNumber(""));
        }
        [TestCase]
        public void ValidateNumberDouble()
        {
            Assert.AreEqual(true, objnumbertowords.ValidateNumber("33.11"));
        }
        #endregion
        #region Name Validation Test Cases

        [TestCase]
        public void ValidateName()
        {
            Assert.AreEqual(true, objnumbertowords.ValidateName("Robin"));
        }
        [TestCase]
        public void ValidateNameNumber()
        {
            Assert.AreEqual(true, objnumbertowords.ValidateName("Albert123"));
        }
        [TestCase]
        public void ValidateNameEmpty()
        {
            Assert.AreEqual(true, objnumbertowords.ValidateName(""));
        }

        #endregion
        #region Numbert To Word Test Case

        [TestCase]
        public void ConvertNumbersToWords()
        {
            Assert.AreEqual("Thirty Three DOLLARS and  Three Cents Only", objnumbertowords.ConvertNumbersToWords("33.3"));
        }
        [TestCase]
        public void ConvertNumbersToWordsMinVal()
        {
            Assert.AreEqual("Zero DOLLARS Only", objnumbertowords.ConvertNumbersToWords("0"));
        }
        [TestCase]
        public void ConvertNumbersToWordsMAXVal()
        {
            Assert.AreEqual("Nine Trillion Nine Hundred Ninety Nine Billion Nine Hundred Ninety Nine Million Nine Hundred Ninety Nine Thousand Nine Hundred Ninety Nine DOLLARS Only", objnumbertowords.ConvertNumbersToWords("9999999999999"));
        }
        [TestCase]
        public void ConvertNumbersToWordsEmpty()
        {
            Assert.AreEqual("Zero DOLLARS Only", objnumbertowords.ConvertNumbersToWords(""));
        }

        #endregion
    }
}