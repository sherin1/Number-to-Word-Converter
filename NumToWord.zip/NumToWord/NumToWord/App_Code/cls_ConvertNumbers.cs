﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace NumToWord.App_Code
{
    public class cls_ConvertNumbers
    {
        public int Id;
        public string PersonName;
        public string OrignalNumber;
        public string ConvertedNumber;

        public int Insert()
        {
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["NTWConnectionString"].ToString());
            con.Open();

            SqlCommand cmd = new SqlCommand();
            cmd.CommandType = CommandType.Text;
            string query = "INSERT INTO ConvertNumber(PersonName,OrginalNumber,ConvertedNumber) VALUES (@PersonName,@OrginalNumber,@ConvertedNumber)";
            cmd = new SqlCommand(query, con);
            cmd.Parameters.AddWithValue("@PersonName", PersonName);
            cmd.Parameters.AddWithValue("@OrginalNumber", OrignalNumber);
            cmd.Parameters.AddWithValue("@ConvertedNumber", ConvertedNumber);

            int i = cmd.ExecuteNonQuery();

            con.Close();

            return i;
        }
    }
}